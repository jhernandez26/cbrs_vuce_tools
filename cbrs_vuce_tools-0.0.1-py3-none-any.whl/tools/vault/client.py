import hvac
from .config import VAULT_ADDR, VAULT_TOKEN

class VaultClient:
    def __init__(self):
        self.client = hvac.Client(url=VAULT_ADDR, token=VAULT_TOKEN)
        if not self.client.is_authenticated():
            raise Exception("Vault authentication failed.")

    def get_client(self):
        return self.client
